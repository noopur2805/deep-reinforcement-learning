# Temporal-Difference Methods

### Instructions

Follow the instructions in `Temporal_Difference.ipynb` to write your own implementations of many temporal-difference methods!  The corresponding solutions can be found in `Temporal_Difference_Solution.ipynb`.  
